-------------------------flow_style--------------------------

-------------------------frame_style--------------------------

data.raw["gui-style"].default["fnei_hotbar_frame"] =
{
  type = "frame_style",
  top_padding = 1,
  right_padding = 1,
  bottom_padding = 1,
  left_padding = 1,
  title_top_padding = 0,
  title_right_padding = 0,
  title_bottom_padding = 0,
  title_left_padding = 0,
  scalable = false,
}

-------------------------table_style--------------------------

-------------------------label_style--------------------------

------------------------button_style-------------------------

data.raw["gui-style"].default["fnei_hotbar_label_button"] = 
{
  type = "button_style",
  parent = "technology_slot_button",
  height = 30,
  width = 40,
  font = "font-lb",
  scalable = false,
}