require("prototypes.oil-boiler")
require("prototypes.turbine")
require("prototypes.burner-generator")
require("prototypes.diesel-generator")
