-- This ought to be in data-updates, but these modifications need to run BEFORE
-- aai-programmable-vehicles runs its data-updates and copies car entities.

-- support routines
local function xcompat_set_grid (vehicle_id, grid_id)
	local vehicle = data.raw["car"][vehicle_id]
	if vehicle then
		vehicle.equipment_grid = grid_id
	else
	end
end

local function xcompat_exclude(array, element)
	local copy = {}
	for i, v in ipairs(array) do
		if v ~= element then
			table.insert(copy, v)
		end
	end
	return copy
end

local function xcompat_adjust_grid(grid_id, additions)
	local grid = data.raw["equipment-grid"][grid_id]
	if grid then
		local equipment_categories = xcompat_exclude(grid.equipment_categories, "armor")
		for i, v in ipairs(additions) do
			table.insert(equipment_categories, v)
		end
		grid.equipment_categories = equipment_categories
	end
end

-- AAI
if data.raw["car"]["vehicle-flame-tumbler"] then
	data:extend({
		{
			type = "equipment-category",
			name = "performance-car"
		},
		{
			type = "equipment-grid",
			name = "flame-tumbler-equipment-grid",
			width = 8,
			height = 4,
			equipment_categories = {"vehicle", "car", "performance-car", "armoured-vehicle"}
		},
	})
	data.raw["car"]["vehicle-flame-tumbler"].equipment_grid = "flame-tumbler-equipment-grid"
end
xcompat_set_grid("vehicle-miner", "bob-tank")
xcompat_set_grid("vehicle-miner-mk2", "bob-tank")
xcompat_set_grid("vehicle-miner-mk3", "bob-tank")
xcompat_set_grid("vehicle-miner-mk4", "bob-tank-2")
xcompat_set_grid("vehicle-miner-mk5", "bob-tank-3")
xcompat_set_grid("vehicle-chaingunner", "bob-tank")
xcompat_set_grid("vehicle-hauler", "bob-tank")
xcompat_set_grid("vehicle-flame-tank", "bob-tank-2")
xcompat_set_grid("vehicle-laser-tank", "bob-tank-2")
xcompat_set_grid("vehicle-warden", "bob-tank-3")

-- Aircraft
if data.raw["car"]["cargo-plane"] then
	data:extend({
		{
			type = "equipment-grid",
			name = "cargo-plane-equipment-grid",
			width = 8,
			height = 2,
			equipment_categories = {"aircraft", "vehicle"}
		},
	})
	data.raw["car"]["cargo-plane"].equipment_grid = "cargo-plane-equipment-grid"
end
if data.raw["technology"]["aircraft-energy-shield"] then
	data.raw["technology"]["aircraft-energy-shield"].enabled = false
end

-- afterburner buff to keep it in line with Bob's other equipment
local afterburner = data.raw["movement-bonus-equipment"]["aircraft-afterburner"]
if afterburner then
	-- flame tumbler insanity
	if data.raw["equipment-category"]["performance-car"] then
		table.insert(afterburner.categories, "performance-car") -- zoom zoom
	end
	afterburner.shape.height = 2
	afterburner.shape.width = 2
	afterburner.energy_consumption = "1050kW"
	afterburner.movement_bonus = 0.9
end
xcompat_adjust_grid("gunship-equipment-grid", {"vehicle", "armoured-vehicle"})
xcompat_adjust_grid("jet-equipment-grid", {"vehicle"})
xcompat_adjust_grid("flying-fortress-equipment-grid", {"vehicle", "armoured-vehicle"})
