# ScienceCostTweakerM
This mod is derivate from Uberwafe's Science Cost Tweaker mod for Factorio version 0.15.

Factorio Mod : Adjusts the cost of science packs and research.
