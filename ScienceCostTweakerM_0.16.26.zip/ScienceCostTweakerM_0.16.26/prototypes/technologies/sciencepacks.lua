-- Tier 2, enabled by Automation 2 research (which is also enables science pack 2)
table.insert(data.raw.technology["automation-2"].effects,{type = "unlock-recipe", recipe = "science-pack-2"})

