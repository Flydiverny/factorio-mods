if mods["angelsbioprocessing"] then
	require("tweaks.angelsmods.science")
end
