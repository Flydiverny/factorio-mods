if mods["bobtech"] then
	require("tweaks.bobsmods.science")
end
