if data.raw.tool["science-pack-4"] then

    data:extend(
    {
		{
		type = "technology",
		name = "ftl-theory-D",
		icon = "__SpaceMod__/graphics/technology/ftl.png",	
		prerequisites = {"ftl-theory-C"},
		unit =
		{
		count = 200000,
		ingredients =
		{
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1},
			{"science-pack-4", 1},
		},
		time = 60
		},
		order = "k-o-a"
	}
	}
	)

	bobmods.lib.tech.add_science_pack("space-assembly", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("space-construction", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("space-casings", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("protection-fields", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("fusion-reactor", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("space-thrusters", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("fuel-cells", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("habitation", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("life-support-systems", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("spaceship-command", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("astrometrics", "science-pack-4", 1)
	bobmods.lib.tech.add_science_pack("ftl-propulsion", "science-pack-4", 1)

-- data.raw.technology["space-assembly"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }

-- data.raw.technology["space-construction"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }

-- data.raw.technology["space-casings"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }

-- data.raw.technology["protection-fields"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }
	  
-- data.raw.technology["fusion-reactor"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }	  
	  
-- data.raw.technology["space-thrusters"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }	  
	  
-- data.raw.technology["fuel-cells"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }	  
	  
-- data.raw.technology["habitation"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }	  
	  
-- data.raw.technology["life-support-systems"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }

-- data.raw.technology["spaceship-command"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }

-- data.raw.technology["astrometrics"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }
	  
-- data.raw.technology["ftl-propulsion"].unit.ingredients =
      -- {
        -- {"science-pack-1", 1},
        -- {"science-pack-2", 1},
		-- {"science-pack-3", 1},
		-- {"science-pack-4", 1},
		-- {"alien-science-pack", 1}
      -- }	  

    data.raw.technology["ftl-theory-A"].unit.count = 200000
    data.raw.technology["ftl-theory-B"].unit.count = 200000
    data.raw.technology["ftl-theory-C"].unit.count = 200000
    data.raw.technology["ftl-propulsion"].unit.count = 200000

    bobmods.lib.tech.replace_prerequisite("ftl-propulsion", "ftl-theory-C", "ftl-theory-D")

end

bobmods.lib.tech.add_prerequisite("space-assembly", "bob-robots-3")	

if bobmods.modules.EnableGodModules == true then
	bobmods.lib.tech.add_prerequisite("space-assembly", "god-module-5")
--    data.raw.technology["space-assembly"].prerequisites = {"god-module-5","rocket-silo","bob-robots-3"}
else
	bobmods.lib.tech.add_prerequisite("space-assembly", "speed-module-8")
	bobmods.lib.tech.add_prerequisite("space-assembly", "effectivity-module-8")
--    data.raw.technology["space-assembly"].prerequisites = {"speed-module-8","effectivity-module-8","rocket-silo","bob-robots-3"}
	bobmods.lib.tech.add_prerequisite("ftl-propulsion", "productivity-module-8")
--    data.raw.technology["ftl-propulsion"].prerequisites = {"productivity-module-8","ftl-theory-D"}	
end

bobmods.lib.tech.add_prerequisite("space-construction", "bob-robo-modular-4")	
-- data.raw.technology["space-construction"].prerequisites = {"space-assembly","bob-robo-modular-4"}
bobmods.lib.tech.add_prerequisite("protection-fields", "energy-shield-equipment-6")
-- data.raw.technology["protection-fields"].prerequisites = {"space-construction","energy-shield-equipment-6"}
bobmods.lib.tech.add_prerequisite("fusion-reactor", "fusion-reactor-equipment-4")
-- data.raw.technology["fusion-reactor"].prerequisites = {"space-construction","fusion-reactor-equipment-4"}

bobmods.lib.tech.add_prerequisite("rocket-silo", "titanium-processing")
bobmods.lib.tech.add_prerequisite("rocket-silo", "nitinol-processing")
bobmods.lib.tech.add_prerequisite("rocket-silo", "electric-energy-accumulators-4")
bobmods.lib.tech.add_prerequisite("rocket-silo", "bob-solar-energy-4")
bobmods.lib.tech.add_prerequisite("rocket-silo", "advanced-electronics-3")
bobmods.lib.tech.add_prerequisite("rocket-silo", "radars-4")

-- alternate protection field recipe enabler
bobmods.lib.tech.add_recipe_unlock("protection-fields", "protection-field-goopless")