data:extend({
  {
    type = "item",
    name = "assembly-robot",
    icon = "__SpaceMod__/graphics/icons/assembly-robot.png",
	icon_size = 37,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "p[assembly-robot]",
    stack_size = 50
  },
  {
    type = "item",
    name = "drydock-assembly",
    icon = "__SpaceMod__/graphics/icons/drydock-assembly.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "q[drydock-assembly]",
    stack_size = 1
  }, 
  {
    type = "item",
    name = "drydock-structural",
    icon = "__SpaceMod__/graphics/icons/drydock-structural.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "r[drydock-structural]",
    stack_size = 1
  },   
  {
    type = "item",
    name = "fusion-reactor",
    icon = "__SpaceMod__/graphics/icons/fusion-reactor.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "s[fusion-reactor]",
    stack_size = 1
  },   
  {
    type = "item",
    name = "hull-component",
    icon = "__SpaceMod__/graphics/icons/hull-component.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "t[hull-component]",
    stack_size = 1
  }, 
  {
    type = "item",
    name = "protection-field",
    icon = "__SpaceMod__/graphics/icons/protection-field.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "u[protection-field]",
    stack_size = 1
  },  
  {
    type = "item",
    name = "space-thruster",
    icon = "__SpaceMod__/graphics/icons/space-thruster.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "v[space-thruster]",
    stack_size = 1
  }, 
  {
    type = "item",
    name = "fuel-cell",
    icon = "__SpaceMod__/graphics/icons/fuel-cell.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "w[fuel-cell]",
    stack_size = 1
  },  
  {
    type = "item",
    name = "habitation",
    icon = "__SpaceMod__/graphics/icons/habitation.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "x[habitation]",
    stack_size = 1
  },  
  {
    type = "item",
    name = "life-support",
    icon = "__SpaceMod__/graphics/icons/life-support.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "y[life-support]",
    stack_size = 1
  },
  {
    type = "item",
    name = "command",
    icon = "__SpaceMod__/graphics/icons/command.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "z-a[command]",
    stack_size = 1
  }, 
  {
    type = "item",
    name = "astrometrics",
    icon = "__SpaceMod__/graphics/icons/astrometrics.png",
	icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "z-b[astrometrics]",
    stack_size = 1
  },  
  {
    type = "item",
    name = "ftl-drive",
    icon = "__SpaceMod__/graphics/icons/ftl-drive.png",
	icon_size = 32,	
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "z-c[ftl-drive]",
    stack_size = 1
  },     
})