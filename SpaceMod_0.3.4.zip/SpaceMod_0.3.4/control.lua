-- require "defines"
require "util"
require("mod-gui")

MOD_NAME = "SpaceMod"



local launchMult
local launchProfile = settings.startup["SpaceX-launch-profile"]
if launchProfile.value == "Classic" then
	launchMult = 1
elseif launchProfile.value == "Launch Mania(x5)" then
	launchMult = 5
elseif launchProfile.value == "Launch Meglo-mania(x25)" then
	launchMult = 25
else
    launchMult = 1
end

spaceshiprequirements = {
   satellite = 7 * launchMult,
   drydockstructure = 10 * launchMult,
   drydockcommand = 2 * launchMult,
   shipcasings = 10 * launchMult,
   shipthrusters = 4 * launchMult,
   shiptprotectionfield = 1 * launchMult,
   shipfusionreactor = 1 * launchMult,
   shipfuelcells = 2 * launchMult,
   shiphabitation = 1 * launchMult,
   shiplifesupport = 1 * launchMult,
   shipastrometrics = 1 * launchMult,
   shipcommand = 1 * launchMult,
   shipftldrive = 1 * launchMult
   }

local function glob_init()

  global = global or {}
  global.requirements = spaceshiprequirements
  if global.launches == nil then
    global.launches = {
      satellite = 0,
      drydockstructure = 0,
      drydockcommand = 0,
      shipcasings = 0,
      shipthrusters = 0,
      shiptprotectionfield = 0,
      shipfusionreactor = 0,
      shipfuelcells = 0,
      shiphabitation = 0,
      shiplifesupport = 0,
      shipastrometrics = 0,
      shipcommand = 0,
      shipftldrive = 0
	  }
	end
end

local function gui_init(player, after_research)

	local button = mod_gui.get_button_flow(player).space_toggle_button
    if button then
	  if player.force.technologies["rocket-silo"].researched ~= true then
        button.destroy() 
	  end
      return	  
    end 

    if (player.force.technologies["rocket-silo"].researched or after_research) then

        -- player.gui.top.add{
		mod_gui.get_button_flow(player).add{
            type = "button",
            name = "space_toggle_button",
			style = mod_gui.button_style,
            caption = {"space-toggle-button-caption"}
        }
		
    end

end

local function on_player_created(event)
  gui_init(game.players[event.player_index], false)
end


function gui_open_frame(player)

	local frame = mod_gui.get_frame_flow(player).space_progress_frame
	
	-- if frame then 
	if not frame then return end
	frame.clear()

    -- Now we can build the GUI.
	
	local sat_title = frame.add{type = "label", caption = {"satellite-network-progress-title"}, style = "caption_label"}
	local satellite = frame.add{type = "table", name = "satellite", column_count = 2, style = "SpaceMod_table_style"}
	satellite.style.column_alignments[2] = "right"	
    satellite.add{type = "label", caption = "-Satellites launched : "}
	satellite.add{type = "label", caption = global.launches.satellite .. "/" .. global.requirements.satellite}
	

	-- Test for satellite network established condition
	if global.launches.satellite < global.requirements.satellite then
	  return
	end

--    drydock_frame_title(drydock)	
	local drydock_title = frame.add{type = "label", caption = {"drydock-progress-title"}, style = "caption_label"}
	local drydock = frame.add{type = "table", name = "drydock", column_count = 2, style = "SpaceMod_table_style"}
	drydock.style.column_alignments[2] = "right"
	drydock.add{type = "label", caption = "-Drydock Structure Component : "}
	drydock.add{type = "label", caption = global.launches.drydockstructure .. "/" .. global.requirements.drydockstructure}
	drydock.add{type = "label", caption = "-Drydock Assembly Component : "}
	drydock.add{type = "label", caption = global.launches.drydockcommand .. "/" .. global.requirements.drydockcommand}
	
	-- Test for drydock built condition
	if (global.launches.drydockstructure < global.requirements.drydockstructure or 
		global.launches.drydockcommand < global.requirements.drydockcommand) then
		return
	end
	
	local ship_title = frame.add{type = "label", caption = {"ship-progress-title"}, style = "caption_label"}
	local gui_ship = frame.add{type = "table", name = "ship", column_count = 2, style = "SpaceMod_table_style"}
	gui_ship.style.column_alignments[2] = "right"
	gui_ship.add{type = "label", caption = "-Protection Field...... : "}
	gui_ship.add{type = "label", caption = global.launches.shiptprotectionfield .. "/" .. global.requirements.shiptprotectionfield}
	gui_ship.add{type = "label", caption = "-Fusion Reactor........ : "}
	gui_ship.add{type = "label", caption = global.launches.shipfusionreactor .. "/" .. global.requirements.shipfusionreactor }
	gui_ship.add{type = "label", caption = "-Habitation............... : "}	
	gui_ship.add{type = "label", caption = global.launches.shiphabitation .. "/" .. global.requirements.shiphabitation}
	gui_ship.add{type = "label", caption = "-Life Support........... : "}	
	gui_ship.add{type = "label", caption = global.launches.shiplifesupport .. "/" .. global.requirements.shiplifesupport}
	gui_ship.add{type = "label", caption = "-Astrometrics.......... : "}	
	gui_ship.add{type = "label", caption = global.launches.shipastrometrics .. "/" .. global.requirements.shipastrometrics}
	gui_ship.add{type = "label", caption = "-Command................ : "}	
	gui_ship.add{type = "label", caption = global.launches.shipcommand .. "/" .. global.requirements.shipcommand}
	gui_ship.add{type = "label", caption = "-Fuel Cells............... : "}	
	gui_ship.add{type = "label", caption = global.launches.shipfuelcells .. "/" .. global.requirements.shipfuelcells}
	gui_ship.add{type = "label", caption = "-Thrusters.............. : "}	
	gui_ship.add{type = "label", caption = global.launches.shipthrusters .. "/" .. global.requirements.shipthrusters}
	gui_ship.add{type = "label", caption = "-Hull components.. : "}	
	gui_ship.add{type = "label", caption = global.launches.shipcasings .. "/" .. global.requirements.shipcasings}
	gui_ship.add{type = "label", caption = "-FTL drive............. : "}	
	gui_ship.add{type = "label", caption = global.launches.shipftldrive .. "/" .. global.requirements.shipftldrive}
	
end

local function on_configuration_changed(data)
  if not data or not data.mod_changes then
    return
  end
  -- if data.mod_changes[MOD_NAME] then
-- --    glob_init()
   -- end	
	local status,err = pcall(function()
		if game.players ~= nil then
			for _, player in pairs(game.players) do
				local frame = player.gui.left["space-progress-frame"]
				if frame then
					frame.destroy()					
				end
				local button = player.gui.top["space-toggle-button"]
				if button then
					button.destroy()
				end
				gui_init(player, player.force.technologies["rocket-silo"].researched)

				player.print("Mod version changed processed")
			end
		end
	end)
  end


script.on_event(defines.events.on_gui_click, function(event) 

    local element = event.element
    local player = game.players[event.player_index]
  local gui = mod_gui.get_frame_flow(player)
  local frame = gui.space_progress_frame

    if element.name == "space_toggle_button" then
	    if frame then
			frame.destroy()
			return
		end
		frame = gui.add{
			type = "frame",
			name = "space_progress_frame",
			direction = "vertical",
			caption = {"space-progress-frame-title"},
			style = mod_gui.frame_style
		}		
        gui_open_frame(player)

    end
	
--	if player.gui.left["rocket_score"] ~= nil then
--	  player.gui.left["rocket_score"].destroy()
--	end

end)

script.on_event(defines.events.on_research_finished, function(event)

    if event.research.name == 'rocket-silo' then
        for _, player in pairs(game.players) do
            gui_init(player, true)
        end
    end

end)

script.on_init(function()

    glob_init()

    for _, player in pairs(game.players) do
        gui_init(player, false)
    end
	
end)


script.on_event(defines.events.on_player_created, on_player_created)
script.on_configuration_changed(on_configuration_changed)

script.on_event(defines.events.on_rocket_launched, function(event)
  remote.call("silo_script","set_show_launched_without_satellite", false)
  remote.call("silo_script","set_finish_on_launch", false)
  local force = event.rocket.force
  if event.rocket.get_item_count("satellite") > 0 then
    if global.launches.satellite < global.requirements.satellite then
	  global.launches.satellite = global.launches.satellite + 1	
		if global.launches.satellite == global.requirements.satellite then

			for _, player in pairs(game.players) do
				player.print({"satellite-network-complete-msg"}) 
			end	  
		end	  
	end
	game.set_game_state{game_finished=false, player_won=false, can_continue=true}	

--	for index, player in pairs(force.players) do
--		if player.gui.left["rocket_score"] ~= nil then
--			player.gui.left["rocket_score"].destroy()
--		end
--	end
	for _, player in pairs(game.players) do
		-- frame = player.gui.left["space-progress-frame"]
		local frame = mod_gui.get_frame_flow(player).space_progress_frame
		if frame then
			frame.clear()
			gui_open_frame(player)
		end
	end		
	return
  end
  
	if event.rocket.get_item_count("drydock-structural") > 0 then
		if global.launches.drydockstructure < global.requirements.drydockstructure then
			global.launches.drydockstructure = global.launches.drydockstructure + 1
		end

	end
  
	if event.rocket.get_item_count("drydock-assembly") > 0 then
		if global.launches.drydockcommand < global.requirements.drydockcommand then
			global.launches.drydockcommand = global.launches.drydockcommand + 1
		end

	end  

--	local condition = (ship == nil) and (global.launches.drydockstructure = global.requirements.drydockstructure) and (global.launches.drydockcommand = globallaunches.drydockcommand)			
						
	if ((event.rocket.get_item_count("drydock-structural") > 0 or event.rocket.get_item_count("drydock-assembly") > 0) and
		global.launches.drydockstructure == global.requirements.drydockstructure and
		global.launches.drydockcommand == global.requirements.drydockcommand) then
				for _, player in pairs(game.players) do
					player.print({"drydock-complete-msg"}) 
				end

	end

	if event.rocket.get_item_count("fusion-reactor") > 0 then
		if global.launches.shipfusionreactor < global.requirements.shipfusionreactor then
			global.launches.shipfusionreactor = global.launches.shipfusionreactor + 1
		end

	end  

	if event.rocket.get_item_count("fuel-cell") > 0 then
		if global.launches.shipfuelcells < global.requirements.shipfuelcells then
			global.launches.shipfuelcells = global.launches.shipfuelcells + 1
		end

	end 	

	if event.rocket.get_item_count("hull-component") > 0 then
		if global.launches.shipcasings < global.requirements.shipcasings then
			global.launches.shipcasings = global.launches.shipcasings + 1
		end

	end 

	if event.rocket.get_item_count("protection-field") > 0 then
		if global.launches.shiptprotectionfield < global.requirements.shiptprotectionfield then
			global.launches.shiptprotectionfield = global.launches.shiptprotectionfield + 1
		end

	end 

	if event.rocket.get_item_count("space-thruster") > 0 then
		if global.launches.shipthrusters < global.requirements.shipthrusters then
			global.launches.shipthrusters = global.launches.shipthrusters + 1
		end

	end 

	if event.rocket.get_item_count("habitation") > 0 then
		if global.launches.shiphabitation < global.requirements.shiphabitation then
			global.launches.shiphabitation = global.launches.shiphabitation + 1
		end

	end

	if event.rocket.get_item_count("life-support") > 0 then
		if global.launches.shiplifesupport < global.requirements.shiplifesupport then
			global.launches.shiplifesupport = global.launches.shiplifesupport + 1
		end

	end  

	if event.rocket.get_item_count("command") > 0 then
		if global.launches.shipcommand < global.requirements.shipcommand then
			global.launches.shipcommand = global.launches.shipcommand + 1
		end

	end 

	if event.rocket.get_item_count("astrometrics") > 0 then
		if global.launches.shipastrometrics < global.requirements.shipastrometrics then
			global.launches.shipastrometrics = global.launches.shipastrometrics + 1
		end

	end 

	if event.rocket.get_item_count("ftl-drive") > 0 then
		if global.launches.shipftldrive < global.requirements.shipftldrive then
			global.launches.shipftldrive = global.launches.shipftldrive + 1
		end
	end  

	-- Test for victory condition
	global.finished = global.finished or false
	
	if  global.launches.shipfusionreactor == global.requirements.shipfusionreactor and
		global.launches.shipcasings == global.requirements.shipcasings and
		global.launches.shiptprotectionfield == global.requirements.shiptprotectionfield and
		global.launches.shipthrusters == global.requirements.shipthrusters and
		global.launches.shiphabitation == global.requirements.shiphabitation and
		global.launches.shiplifesupport == global.requirements.shiplifesupport and
		global.launches.shipcommand == global.requirements.shipcommand and
		global.launches.shipastrometrics == global.requirements.shipastrometrics and
		global.launches.shipftldrive == global.requirements.shipftldrive and
		global.finished == false then
		for _, player in pairs(game.players) do
			player.print({"spaceship-complete-msg"}) 
		end
		game.set_game_state{game_finished=true, player_won=true, can_continue=true}
		global.finished = true
	end
	for _, player in pairs(game.players) do
		frame = mod_gui.get_frame_flow(player).space_progress_frame
		if frame then
			gui_open_frame(player)
		end
	end	
--	if (#game.players <= 1) then
--		ipc.keypress(9)
--	end
end)