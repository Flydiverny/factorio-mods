require("prototypes.technology")
require("prototypes.style")
require("prototypes.item")
require("prototypes.recipe")

-- if (not bobmods) then 
  -- bobmods = {} 
-- elseif (bobmods.lib and 
        -- bobmods.modules and 
		-- bobmods.warfare and
		-- data.raw.recipe["advanced-processing-unit"]) then
  -- require("prototypes.recipe-bobs")
	-- require("prototypes.technology-bobs")
-- end
