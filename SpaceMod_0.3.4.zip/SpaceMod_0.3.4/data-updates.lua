--require("item-functions")
--require("recipe-functions")

local researchCost = settings.startup["SpaceX-research"]
if researchCost == nil then
	researchCost.value = 1
end

local ignoreMult = settings.startup["SpaceX-ignore-tech-multiplier"]
local noSpace = settings.startup["SpaceX-no-space-sci"]
local cheapFusion = settings.startup["SpaceX-cheaper-fusion-reactor"]

local SpaceXTechs = {
"space-assembly",
"space-construction",
"space-casings",
"protection-fields",
"fusion-reactor",
"space-thrusters",
"fuel-cells",
"habitation",
"life-support-systems",
"spaceship-command",
"astrometrics",
"ftl-theory-A",
"ftl-theory-B",
"ftl-theory-C",
"ftl-propulsion",
}

for i, tech in pairs(SpaceXTechs) do
	local rootTech = data.raw.technology[tech]
	if rootTech ~= nil then
		rootTech.unit.count = rootTech.unit.count * researchCost.value
		if ignoreMult == true then
		  rootTech.unit.count = rootTech.unit.count / 4
		end
	end
end

local productionCost = settings.startup["SpaceX-production"]
if productionCost == nil then
	productionCost.value = 1
end

-- local SpaceXRecipes = {
-- "drydock-assembly",
-- "drydock-structural",
-- "fusion-reactor",
-- "hull-component",
-- "protection-field",
-- "space-thruster",
-- "fuel-cell",
-- "habitation",
-- "life-support",
-- "command",
-- "astrometrics",
-- "ftl-drive",
-- }

-- for j, recipe in pairs(SpaceXRecipes) do
	-- local rootRecipe = data.raw.recipe[recipe]
	-- if rootRecipe ~= nil then
		-- local tableIngredients = rootRecipe.Ingredients
		-- for k, ingredient in pairs(tableIngredients) do
			-- local oldIngredient = rootRecipe.Ingredients[Ingredient]
			-- local amount = oldIngredient.amount * productionCost.value
			-- local newIngredient = oldIngredient
			-- newIngredient.amount = amount
			-- bobmods.lib.recipe.replace_ingredient(rootRecipe, oldIngredient, newIngredient)
-- --			data.raw.recipe[recipe].Ingredients[Ingredient].amount = rootIngredient.amount*productionCost.value
		-- end
	-- end
-- end

local fix = data.raw.recipe["drydock-assembly"]
fix.ingredients =
    {
      {"assembly-robot", 50*productionCost.value},
      {"roboport", 10*productionCost.value},
      {"processing-unit", 200*productionCost.value},
	  {"solar-panel", 200*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }

fix = data.raw.recipe["drydock-structural"]
fix.ingredients =
    {
      {"low-density-structure", 200*productionCost.value}
    }

fix = data.raw.recipe["fusion-reactor"]
if cheapFusion == true then
	fix.ingredients =
		{
		{"fusion-reactor-equipment", 40*productionCost.value}
		}
else
	fix.ingredients =
		{
		{"fusion-reactor-equipment", 100*productionCost.value}
		}
end

fix = data.raw.recipe["hull-component"]
fix.ingredients =
    {
	  {"low-density-structure", 250*productionCost.value},
	  {"steel-plate", 100*productionCost.value}
    }
	
fix = data.raw.recipe["protection-field"]
fix.ingredients =
    {
	  {"energy-shield-mk2-equipment", 100*productionCost.value}
    }
	
fix = data.raw.recipe["space-thruster"]
fix.ingredients =
    {
      {"speed-module-3", 50*productionCost.value},
      {"pipe", 100*productionCost.value},
      {"processing-unit", 100*productionCost.value},
	  {"electric-engine-unit", 100*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["fuel-cell"]
fix.ingredients =
    {
      {"steel-plate", 100*productionCost.value},
      {"rocket-fuel", 500*productionCost.value},
      {"processing-unit", 100*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["habitation"]
fix.ingredients =
    {
      {"steel-plate", 100*productionCost.value},
      {"plastic-bar", 500*productionCost.value},
      {"processing-unit", 100*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["life-support"]
fix.ingredients =
    {
      {"productivity-module-3", 50*productionCost.value},
      {"pipe", 200*productionCost.value},
      {"processing-unit", 100*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["command"]
fix.ingredients =
    {
      {"speed-module-3", 50*productionCost.value},
	  {"effectivity-module-3", 50*productionCost.value},
	  {"productivity-module-3", 50*productionCost.value},
      {"plastic-bar", 200*productionCost.value},
      {"processing-unit", 100*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["astrometrics"]
fix.ingredients =
    {
      {"speed-module-3", 50*productionCost.value},
      {"processing-unit", 300*productionCost.value},
	  {"low-density-structure", 100*productionCost.value}
    }
	
fix = data.raw.recipe["ftl-drive"]
fix.ingredients =
    {
      {"productivity-module-3", 500*productionCost.value},
      {"speed-module-3", 500*productionCost.value},
      {"effectivity-module-3", 500*productionCost.value},
	  {"low-density-structure", 100*productionCost.value},
	  {"processing-unit", 500*productionCost.value}
    }
	
if noSpace == true then
	fix = data.raw.technology["ftl-propulsion"]
    fix.unit.ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
		{"science-pack-3", 1},
		{"production-science-pack", 1},
		{"high-tech-science-pack", 1},
      }
end
