require("defines")

require("prototypes.recipe")
require("prototypes.recipe1")
require("prototypes.recipe_electro")
require("prototypes.solder")
require("prototypes.cable")