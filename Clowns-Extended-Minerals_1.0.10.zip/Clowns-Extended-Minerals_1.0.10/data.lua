require("prototypes.generation.clowns-ore1")
require("prototypes.generation.clowns-ore2")
require("prototypes.generation.clowns-ore3")
require("prototypes.generation.clowns-ore4")
require("prototypes.generation.clowns-ore5")
require("prototypes.generation.clowns-ore6")
require("prototypes.generation.clowns-ore7")
--require("prototypes.generation.clowns-ore8")

require("prototypes.generation.infinite-clowns-ore1")
require("prototypes.generation.infinite-clowns-ore2")
require("prototypes.generation.infinite-clowns-ore3")
require("prototypes.generation.infinite-clowns-ore4")
require("prototypes.generation.infinite-clowns-ore5")
require("prototypes.generation.infinite-clowns-ore6")
require("prototypes.generation.infinite-clowns-ore7")
--require("prototypes.generation.infinite-clowns-ore8")

require("prototypes.generation.clowns-resource1")
require("prototypes.generation.clowns-resource2")
--require("prototypes.generation.clowns-resource3")
--require("prototypes.generation.clowns-resource4")
--require("prototypes.generation.clowns-resource5")

require("prototypes.generation.infinite-clowns-resource1")
require("prototypes.generation.infinite-clowns-resource2")

--require("prototypes.buildings.shaft-mine")

require("prototypes.categories")

require("prototypes.items.item-builder")
require("prototypes.items.resource-processing")


require("prototypes.recipes.ore-sorting")
require("prototypes.recipes.ore-refining")
require("prototypes.recipes.liquification")
--require("prototypes.recipes.mining")
require("prototypes.recipes.sluicing")

require("prototypes.technology.water-treatment")
require("prototypes.technology.ore-refining")