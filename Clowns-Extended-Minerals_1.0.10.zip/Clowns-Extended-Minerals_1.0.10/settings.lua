data:extend(
{
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore1",
		setting_type = "startup",
		default_value = true,
		order = "a",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore2",
		setting_type = "startup",
		default_value = true,
		order = "b",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore3",
		setting_type = "startup",
		default_value = true,
		order = "c",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore4",
		setting_type = "startup",
		default_value = true,
		order = "d",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore5",
		setting_type = "startup",
		default_value = true,
		order = "e",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore6",
		setting_type = "startup",
		default_value = true,
		order = "f",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsore7",
		setting_type = "startup",
		default_value = true,
		order = "g",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsresource1",
		setting_type = "startup",
		default_value = true,
		order = "h",
	},
	{
		type = "bool-setting",
		name = "enableinfiniteclownsresource2",
		setting_type = "startup",
		default_value = true,
		order = "i",
	},
}
)