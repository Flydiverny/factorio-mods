data:extend(
{
	{
		type = "recipe",
		name = "clowns-resource2-liquification",
		category = "liquifying",
		subgroup = "petrochem-carbon-oil-feed",
		enabled = false,
		energy_required = 2,
		ingredients ={{type=item, name="clowns-resource2", amount=4}},
		results=
		{
			{type="item", name="solid-oil-residual", amount=1},
			{type="fluid", name="crude-oil", amount=10}
		},
		icon = "__Clowns-Extended-Minerals__/graphics/icons/clowns-resource2.png",
		icon_size = 32,
		order = "a",
	},
}
)