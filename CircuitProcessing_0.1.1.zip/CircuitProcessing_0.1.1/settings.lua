--[[
data:extend({
{
  type = 'bool-setting',
  name = 'cp-override-modules',
  setting_type = 'startup',
  default_value = true,
  per_user = false
}
})
]]--
