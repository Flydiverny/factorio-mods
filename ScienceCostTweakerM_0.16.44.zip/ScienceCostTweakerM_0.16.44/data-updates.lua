require("config")
require("tweaks.productivity-limitations")
-- Technology tweaks
require("prototypes/1_technology")
-- mod tweaks
require("tweaks.angelsmods.1_update")
require("tweaks.bobsmods.1_update")
require("tweaks.omnimatter.1_update")
require("tweaks.pymods.1_update")
require("tweaks.aai.1_update")
