-- fixes

	sctm.debug(serpent.block(data.raw.recipe["sct-t1-pybotle"]))
	sctm.debug(serpent.block(data.raw.recipe["science-pack-1"]))
	sctm.debug(serpent.block(data.raw.recipe["sct-t2-pychip"]))
	sctm.debug(serpent.block(data.raw.recipe["science-pack-2"]))
	sctm.debug(serpent.block(data.raw.recipe["sct-t3-pybatery"]))
	sctm.debug(serpent.block(data.raw.recipe["science-pack-3"]))
	sctm.debug(serpent.block(data.raw.recipe["sct-prod-pycontainer"]))
	sctm.debug(serpent.block(data.raw.recipe["production-science-pack"]))
	sctm.debug(serpent.block(data.raw.technology["sct-research-t1"]))
	sctm.debug(serpent.block(data.raw.technology["sct-research-t2"]))
	sctm.debug(serpent.block(data.raw.technology["sct-research-t3"]))
	sctm.debug(serpent.block(data.raw.technology["sct-research-prod"]))
	