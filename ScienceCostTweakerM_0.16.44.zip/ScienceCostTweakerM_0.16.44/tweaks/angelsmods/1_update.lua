if mods["angelsbioprocessing"] then
	sctm.tech_dependency_add("bio-temperate-farming", "sct-research-bio")
	sctm.tech_dependency_add("bio-swamp-farming", "sct-research-bio")
	sctm.tech_dependency_add("bio-desert-farming", "sct-research-bio")
	sctm.lab_input_add("lab-2", "sct-science-pack-bio")
end
