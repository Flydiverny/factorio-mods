--luacheck: globals bobmods util angelsmods
if bobmods and bobmods.lib then
   bobmods.lib.recipe.replace_ingredient("tkm-inserter-upgrade", "electronic-circuit", "basic-circuit-board")
   bobmods.lib.recipe.replace_ingredient("tkm-electric-mining-drill-upgrade", "electronic-circuit", "basic-circuit-board")
end