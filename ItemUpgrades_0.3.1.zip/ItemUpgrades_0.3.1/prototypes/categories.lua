data:extend(
{
	{
		type = "item-group",
		name = "item-upgrades",
		order = "y",
		inventory_order = "y",
		icon = "__ItemUpgrades__/graphics/item-group/item-upgrades.png",
		icon_size = 64
	},
	{
		type = "item-subgroup",
		name = "item-upgrades-logistics",
		group = "item-upgrades",
		order = "a"
	},
	{
		type = "item-subgroup",
		name = "item-upgrades-production",
		group = "item-upgrades",
		order = "b"
	},
	{
		type = "item-subgroup",
		name = "item-upgrades-combat",
		group = "item-upgrades",
		order = "c"
	},
	{
		type = "item-subgroup",
		name = "item-upgrades-angels",
		group = "item-upgrades",
		order = "d"
	},
	{
		type = "item-subgroup",
		name = "item-upgrades-bobs",
		group = "item-upgrades",
		order = "e"
	}
}
)