-- medium pole
local pole_upgrade = util.table.deepcopy(data.raw.recipe["medium-electric-pole"])
pole_upgrade.name = "tkm-medium-electric-pole-upgrade"
pole_upgrade.subgroup = "item-upgrades-logistics"
pole_upgrade.order = "a"
pole_upgrade.ingredients = {
	{"small-electric-pole", 1},
	{"steel-plate", 2}}
data:extend{pole_upgrade}
table.insert(data.raw["technology"]["electric-energy-distribution-1"].effects, {type = "unlock-recipe",recipe = "tkm-medium-electric-pole-upgrade"})

-- inserter
local inserter_upgrade = util.table.deepcopy(data.raw.recipe["inserter"])
inserter_upgrade.name = "tkm-inserter-upgrade"
inserter_upgrade.subgroup = "item-upgrades-logistics"
inserter_upgrade.order = "b"
inserter_upgrade.ingredients = {
	{"burner-inserter", 1},
	{"electronic-circuit", 1},
	{"iron-plate", 1}}
data:extend{inserter_upgrade}

-- iron chest
local iron_chest_upgrade = util.table.deepcopy(data.raw.recipe["iron-chest"])
iron_chest_upgrade.name = "tkm-iron-chest-upgrade"
iron_chest_upgrade.subgroup = "item-upgrades-logistics"
iron_chest_upgrade.order = "c"
iron_chest_upgrade.ingredients = {
	{"wooden-chest", 1},
	{"iron-plate", 7}}
data:extend{iron_chest_upgrade}

-- steel chest
local steel_chest_upgrade = util.table.deepcopy(data.raw.recipe["steel-chest"])
steel_chest_upgrade.name = "tkm-steel-chest-upgrade"
steel_chest_upgrade.subgroup = "item-upgrades-logistics"
steel_chest_upgrade.order = "d"
steel_chest_upgrade.ingredients = {
	{"iron-chest", 1},
	{"steel-plate", 7}}
data:extend{steel_chest_upgrade}
table.insert(data.raw["technology"]["steel-processing"].effects, {type = "unlock-recipe",recipe = "tkm-steel-chest-upgrade"})

-- steel axe
local axe_upgrade = util.table.deepcopy(data.raw.recipe["steel-axe"])
axe_upgrade.name = "tkm-steel-axe-upgrade"
axe_upgrade.subgroup = "item-upgrades-production"
axe_upgrade.order = "a"
axe_upgrade.ingredients = {
	{"iron-axe", 1},
	{"steel-plate", 5}}
data:extend{axe_upgrade}
table.insert(data.raw["technology"]["steel-processing"].effects, {type = "unlock-recipe",recipe = "tkm-steel-axe-upgrade"})

-- electric mining drill
local drill_upgrade = util.table.deepcopy(data.raw.recipe["electric-mining-drill"])
drill_upgrade.name = "tkm-electric-mining-drill-upgrade"
drill_upgrade.subgroup = "item-upgrades-production"
drill_upgrade.order = "b"
drill_upgrade.ingredients = {
	{"burner-mining-drill", 1},
	{"electronic-circuit", 3},
	{"iron-gear-wheel", 4},
	{"iron-plate", 8}}
data:extend{drill_upgrade}

-- steel furnace
local furnace_upgrade = util.table.deepcopy(data.raw.recipe["steel-furnace"])
furnace_upgrade.name = "tkm-steel-furnace-upgrade"
furnace_upgrade.subgroup = "item-upgrades-production"
furnace_upgrade.order = "c"
furnace_upgrade.ingredients = {
	{"stone-furnace", 1},
	{"steel-plate", 6},
	{"stone-brick", 8}}
data:extend{furnace_upgrade}
table.insert(data.raw["technology"]["advanced-material-processing"].effects, {type = "unlock-recipe",recipe = "tkm-steel-furnace-upgrade"})

-- smg
local smg_upgrade = util.table.deepcopy(data.raw.recipe["submachine-gun"])
smg_upgrade.name = "tkm-submachine-gun-upgrade"
smg_upgrade.subgroup = "item-upgrades-combat"
smg_upgrade.order = "a"
smg_upgrade.ingredients = {
	{"pistol", 1},
	{"iron-gear-wheel", 10},
	{"copper-plate", 2},
	{"iron-plate", 7}}
data:extend{smg_upgrade}
table.insert(data.raw["technology"]["military"].effects, {type = "unlock-recipe",recipe = "tkm-submachine-gun-upgrade"})

-- heavy armor
local heavy_armor_upgrade = util.table.deepcopy(data.raw.recipe["heavy-armor"])
heavy_armor_upgrade.name = "tkm-heavy-armor-upgrade"
heavy_armor_upgrade.subgroup = "item-upgrades-combat"
heavy_armor_upgrade.order = "b"
heavy_armor_upgrade.ingredients = {
	{"light-armor", 1},
	{"copper-plate", 100},
	{"steel-plate", 45}}
data:extend{heavy_armor_upgrade}
table.insert(data.raw["technology"]["heavy-armor"].effects, {type = "unlock-recipe",recipe = "tkm-heavy-armor-upgrade"})

-- modular armor
local modular_armor_upgrade = util.table.deepcopy(data.raw.recipe["modular-armor"])
modular_armor_upgrade.name = "tkm-modular-armor-upgrade"
modular_armor_upgrade.subgroup = "item-upgrades-combat"
modular_armor_upgrade.order = "c"
modular_armor_upgrade.ingredients = {
	{"heavy-armor", 1},
	{"advanced-circuit", 30},
	{"steel-plate", 10}}
data:extend{modular_armor_upgrade}
table.insert(data.raw["technology"]["modular-armor"].effects, {type = "unlock-recipe",recipe = "tkm-modular-armor-upgrade"})

-- power armor
local power_armor_upgrade = util.table.deepcopy(data.raw.recipe["power-armor"])
power_armor_upgrade.name = "tkm-power-armor-upgrade"
power_armor_upgrade.subgroup = "item-upgrades-combat"
power_armor_upgrade.order = "d"
power_armor_upgrade.ingredients = {
	{"modular-armor", 1},
	{"processing-unit", 35},
	{"electric-engine-unit", 20},
	{"steel-plate", 10}}
data:extend{power_armor_upgrade}
table.insert(data.raw["technology"]["power-armor"].effects, {type = "unlock-recipe",recipe = "tkm-power-armor-upgrade"})

-- heavy armor mk2
local power_armor_mk2_upgrade = util.table.deepcopy(data.raw.recipe["power-armor-mk2"])
power_armor_mk2_upgrade.name = "tkm-power-armor-mk2-upgrade"
power_armor_mk2_upgrade.subgroup = "item-upgrades-combat"
power_armor_mk2_upgrade.order = "e"
power_armor_mk2_upgrade.ingredients = {
	{"power-armor", 1},
	{"effectivity-module-3", 5},
	{"speed-module-3", 5},
	{"processing-unit", 30},
	{"steel-plate", 10}}
data:extend{power_armor_mk2_upgrade}
table.insert(data.raw["technology"]["power-armor-2"].effects, {type = "unlock-recipe",recipe = "tkm-power-armor-mk2-upgrade"})