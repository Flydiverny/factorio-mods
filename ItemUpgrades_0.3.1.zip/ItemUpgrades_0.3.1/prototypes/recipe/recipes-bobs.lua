--luacheck: globals bobmods util angelsmods
if bobmods and bobmods.warfare then
	local wall_upgrade = util.table.deepcopy(data.raw.recipe["reinforced-wall"])
	wall_upgrade.name = "tkm-reinforced-wall-upgrade"
	wall_upgrade.subgroup = "item-upgrades-bobs"
	wall_upgrade.order = "a"
	wall_upgrade.ingredients = {
		{"stone-wall", 1},
		{"steel-plate", 3}}
	data:extend{wall_upgrade}
	table.insert(data.raw["technology"]["reinforced-wall"].effects, {type = "unlock-recipe",recipe = "tkm-reinforced-wall-upgrade"})

	local gate_upgrade = util.table.deepcopy(data.raw.recipe["reinforced-gate"])
	gate_upgrade.name = "tkm-reinforced-gate-upgrade"
	gate_upgrade.subgroup = "item-upgrades-bobs"
	gate_upgrade.order = "b"
	gate_upgrade.ingredients = {
		{"gate", 1},
		{"steel-plate", 3}}
	data:extend{gate_upgrade}
	table.insert(data.raw["technology"]["reinforced-wall"].effects, {type = "unlock-recipe",recipe = "tkm-reinforced-gate-upgrade"})
end