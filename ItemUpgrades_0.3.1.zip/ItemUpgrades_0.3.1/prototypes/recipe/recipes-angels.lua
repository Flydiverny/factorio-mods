--luacheck: globals bobmods util angelsmods
if angelsmods and angelsmods.refining then
	local crusher_upgrade = util.table.deepcopy(data.raw.recipe["ore-crusher"])
	crusher_upgrade.name = "tkm-ore-crusher-upgrade"
	crusher_upgrade.subgroup = "item-upgrades-angels"
	crusher_upgrade.order = "a"
	crusher_upgrade.ingredients = {
				{"burner-ore-crusher", 1},
				{"iron-plate", 10},
				{"stone-brick", 8},
				{"iron-gear-wheel", 5}}
	data:extend{crusher_upgrade}
	table.insert(data.raw["technology"]["ore-crushing"].effects, {type = "unlock-recipe",recipe = "tkm-ore-crusher-upgrade"})
end

if angelsmods and (angelsmods.logistics or angelsmods.logitics) then
	local locomotive_upgrade = util.table.deepcopy(data.raw.recipe["crawler-locomotive"])
	locomotive_upgrade.name = "tkm-crawler-locomotive-upgrade"
	locomotive_upgrade.subgroup = "item-upgrades-angels"
	locomotive_upgrade.order = "b"
	locomotive_upgrade.ingredients = {
				{"locomotive", 1},
				{"engine-unit", 5},
				{"steel-plate", 60},
				{"electronic-circuit", 10},
				{"iron-gear-wheel", 25}}
	data:extend{locomotive_upgrade}
	table.insert(data.raw["technology"]["angels-crawler-train"].effects, {type = "unlock-recipe",recipe = "tkm-crawler-locomotive-upgrade"})

	local wagon_upgrade = util.table.deepcopy(data.raw.recipe["crawler-wagon"])
	wagon_upgrade.name = "tkm-crawler-wagon-upgrade"
	wagon_upgrade.subgroup = "item-upgrades-angels"
	wagon_upgrade.order = "c"
	wagon_upgrade.ingredients = {
				{"cargo-wagon", 1},
				{"steel-plate", 35},
				{"iron-plate", 20},
				{"iron-gear-wheel", 15}}
	data:extend{wagon_upgrade}
	table.insert(data.raw["technology"]["angels-crawler-train"].effects, {type = "unlock-recipe",recipe = "tkm-crawler-wagon-upgrade"})
end