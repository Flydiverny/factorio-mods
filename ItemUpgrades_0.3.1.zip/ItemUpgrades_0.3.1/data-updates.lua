require("prototypes.recipe.recipes-vanilla")
require("prototypes.recipe.recipes-bobs")
require("prototypes.recipe.recipes-angels")