local landfills = nil
local function setuptable()
  if landfills ~= nil then
    return
  end
  landfills = {}
  for _,v in pairs({'landfill', 'landfill-dry-dirt', 'landfill-dirt-4',
    'landfill-red-desert-1', 'landfill-sand-3'}) do
    local start = game.item_prototypes[v].place_as_tile_result.result.name
    local current = start
    repeat
      landfills[current] = v
      current = game.tile_prototypes[current].next_direction.name
    until start == current
  end
end

local function tilebuilt(e)
  setuptable()
  local placeitem = e.item.name
  local refundcount = 0
  for _,v in pairs(e.tiles) do
    if landfills[v.old_tile.name] == placeitem then
      refundcount = refundcount + 1
    end
  end
  return {name = placeitem, count = refundcount}
end

script.on_event(defines.events.on_player_built_tile, function(e)
  local refund = tilebuilt(e)
  if refund.count > 0 and e.stack.valid then
    local holding = 0
    if e.stack.valid_for_read then
      holding = e.stack.count
    end
    local fill = math.min(e.item.stack_size - holding, refund.count)
    if fill > 0 then
      e.stack.transfer_stack({name = refund.name, count = fill})
      refund.count = refund.count - fill
    end
  end
  if refund.count > 0 then
    game.players[e.player_index].insert(refund)
  end
end)

script.on_event(defines.events.on_robot_built_tile, function(e)
  local refund = tilebuilt(e)
  if refund.count > 0 then
    e.robot.get_inventory(defines.inventory.robot_cargo).insert(refund)
  end
end)
