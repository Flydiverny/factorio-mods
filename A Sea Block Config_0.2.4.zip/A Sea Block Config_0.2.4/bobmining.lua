seablockconfig:extend({
  {'bobmods-mining-miningdrills', 'bool-setting', false},
  {'bobmods-mining-areadrills', 'bool-setting', false},
  {'bobmods-mining-pumpjacks', 'bool-setting', false},
  {'bobmods-mining-waterminers', 'bool-setting', false}
})
