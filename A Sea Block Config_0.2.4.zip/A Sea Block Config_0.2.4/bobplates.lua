seablockconfig:extend({
  {'bobmods-plates-cheapersteel', 'bool-setting', false}
})
