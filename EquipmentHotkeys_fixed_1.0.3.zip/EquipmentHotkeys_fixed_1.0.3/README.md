Original mod by https://mods.factorio.com/mods/Articulating

Only fixes robots still repairing the vehicle you are driving, even with roboports disabled. 


Adds hotkeys to disabled/enable personal roboports, exoskeletons and night vision. Compatible with bob's mods and should work with any others that add equipment.
The hotkeys can be changed in the Controls option menu, inside the Mods tab. By default the hotkeys are:

F1 to toggle Exoskeletons.

F2 to toggle Personal Roboports.

F8 to toggle Night Vision.

Modsetting to auto disable roboports when entering a vehicle. Autoreenables when leaving the vehicle
###Changelog
1.0.0
 - updated for Factorio 0.16

0.0.4
 - added setting to auto disable roboports when entering a vehicle