data:extend(
	{
        {
			type = "custom-input",
			name = "equipment-toggle-exoskeleton",
			key_sequence = "F1",
			consuming = "script-only"
        },
		{
			type = "custom-input",
			name = "equipment-toggle-personal-roboport",
			key_sequence = "F2",
			consuming = "script-only"
		},
        {
            type = "custom-input",
            name = "equipment-toggle-night-vision",
            key_sequence = "F8",
            consuming = "script-only"
        },

	}
)
