
--This file is kind of silly because this is all it does. :P

fm.gui = {}

require "guiLayout"
require "guiEventHandlers"
