local lib = require "lib"
local function makestripes(filename, count)
  local r = {}
  for i = 1,count do
    table.insert(r, { filename = filename, width_in_frames = 1, height_in_frames = 1 })
  end
  return r
end

local function makeextractorlayers(bottom, top)
  layers = {}
  if top then
    table.insert(layers,
      {
        stripes = makestripes("__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-base.png", 16),
        priority = "high",
        width = 288,
        height = 288,
        shift = {0, 0},
        frame_count = 16,
        x = 288 * 2,
	animation_speed = 0.5
      })
  end
  table.insert(layers,
    {
      priority = "high",
      width = 288,
      height = 288,
      line_length = 4,
      shift = {0, 0},
      filename = "__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-animation.png",
      frame_count = 16,
      animation_speed = 0.5
    })
  if bottom then
    table.insert(layers,
      {
        stripes = makestripes("__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-base.png", 16),
        priority = "high",
        width = 288,
        height = 288,
        shift = {0, 0},
        frame_count = 16,
        x = 0,
	animation_speed = 0.5
      })
  end
  return { layers = layers }
end

-- Make these craftable by hand
data.raw.recipe['solid-alginic-acid'].category = "crafting"
data.raw.recipe['wooden-board-paper'].category = "crafting"

-- Fix handcrafting trying to use wrong crafting path
data.raw.recipe['wooden-board'].category = "electronics-machine"
data.raw.recipe['wooden-board'].enabled = false
table.insert(data.raw.technology['bio-wood-processing-3'].effects,
  {type = "unlock-recipe", recipe = "wooden-board"})

-- Change resin item icon to match resin recipe icon
data.raw.item['resin'].icon = "__angelspetrochem__/graphics/icons/solid-resin-1.png"

-- Add resin prerequisite for advanced electronics
table.insert(data.raw.technology['advanced-electronics'].prerequisites, "resin-1")

-- Increase cost of resin->rubber smelting to encourage use of angels rubber synthesis
lib.substingredient('bob-rubber', 'resin', nil, 4)

-- Add unlock for new solder recipe
table.insert(data.raw.technology['electronics'].effects, { type = "unlock-recipe", recipe = "solder-alginic" })

-- No wood for electric poles, use wood bricks instead
data.raw.recipe['small-electric-pole'].ingredients = {{ "wood-bricks", 1 }, { "copper-cable", 2}}

-- Will need a lot of landfill
data.raw.recipe['landfill'].ingredients = {{ "stone-crushed", 10 }}
for k,v in pairs(data.raw.item) do
  if string.sub(k, 1, 8) == "landfill" then
    v.stack_size = 1000
  end
end

-- Prefer sand for basic landfill crafting
if data.raw.item['landfill-sand-3'] then
  data.raw.recipe['landfill'].result = "landfill-sand-3"
end

-- Speed up algae farm
data.raw['assembling-machine']['algae-farm'].crafting_speed = 1
data.raw['assembling-machine']['algae-farm'].energy_usage = "120kW"

-- Washing plant sulfur byproduct
local washing_fluid_box = {
  production_type = 'output',
  pipe_covers = pipecoverspictures(),
  base_level = 1,
  pipe_connections = {{ position = {-3, 0} }}
}
table.insert(data.raw['assembling-machine']['washing-plant'].fluid_boxes, washing_fluid_box)
table.insert(data.raw['assembling-machine']['washing-plant-2'].fluid_boxes, washing_fluid_box)
table.insert(data.raw.recipe['washing-1'].results,
  {type = "fluid", name = "gas-hydrogen-sulfide", amount = 5}
)

-- Coal removal
lib.substingredient('poison-capsule', 'coal', 'solid-coke')
lib.substingredient('slowdown-capsule', 'coal', 'solid-coke')
lib.substingredient('grenade', 'coal', 'solid-coke')
lib.substingredient('explosives', 'coal', 'solid-coke')
lib.substingredient('solid-fuel-from-hydrogen', 'coal', 'solid-coke')
lib.substingredient('alien-poison', 'coal', 'solid-coke')
lib.substingredient('alien-explosive', 'coal', 'solid-coke')
lib.substingredient('filter-coal', 'coal', 'solid-coke')
lib.substingredient('solid-nitroglycerin', 'coal', 'solid-coke')
lib.substingredient('carbon', 'coal', 'solid-coke')
lib.substingredient('sct-mil-circuit1', 'coal', 'solid-coke')

data.raw.recipe['carbon-separation-2'].energy_required = 1
lib.substingredient('carbon-separation-2', 'coal', 'solid-coke', 1)
data.raw.recipe['carbon-separation-2'].results = {
  {type = 'fluid', name = 'gas-carbon-dioxide', amount = 25}
}

-- Sulfuric acid prerequisites
table.insert(data.raw.technology['slag-processing-1'].prerequisites, 'angels-sulfur-processing-1')
table.insert(data.raw.technology['angels-sulfur-processing-1'].prerequisites, 'water-washing-1')

-- Decrease amount of crushed stone for slag-slurry so it's still better than mineralized water crystallization
lib.findname(data.raw.recipe['stone-crushed-dissolution'].ingredients, 'stone-crushed').amount = 20

-- Angels sludge crystalization usually gives normal smeltable ores. This would be far too easy,
-- so change recipes to give the weird ores that need extra processing steps.
for i = 1,6 do
  local recipe = data.raw.recipe["slag-processing-" .. i]
  recipe.icon = "__angelsrefining__/graphics/icons/angels-ore" .. i .. ".png"
  recipe.localised_name = {"recipe-name.slag-processing-1", {"item-name.angels-ore" .. i}, "", ""}
  recipe.order = "a-a [angels-ore-" .. i .. "]"

  recipe.ingredients = nil
  recipe.results = nil
  recipe.energy_required = nil

  recipe.normal = {
    energy_required = 4,
    ingredients = {{ type="fluid", name = 'mineral-sludge', amount = 25 }},
    results = {{type = "item", name = "angels-ore" .. i, amount = 1 }},
    enabled = false
  }

  recipe.expensive = {
    energy_required = 8,
    ingredients = {{ type="fluid", name = 'mineral-sludge', amount = 50 }},
    results = {{type = "item", name = "angels-ore" .. i, amount = 1 }},
    enabled = false
  }
end
-- Want angels ores 1,3,5,6 (Saphirite, Stiratite, Rubyte, Bobmonium) available from the start,
-- so shuffle crystallization recipe unlocks around
local slag1start = lib.findeffectidx(data.raw.technology['slag-processing-1'].effects, 'slag-processing-1')
local slag2start = lib.findeffectidx(data.raw.technology['slag-processing-2'].effects, 'slag-processing-4')
table.insert(data.raw.technology['slag-processing-2'].effects,
  slag2start + 1,
  lib.takeeffect('slag-processing-1', 'slag-processing-2')) -- move ore2 to slag-processing-2

table.insert(data.raw.technology['slag-processing-1'].effects,
  slag1start + 2,
  lib.takeeffect('slag-processing-2', 'slag-processing-5')) -- move ore5 to slag-processing-1

table.insert(data.raw.technology['slag-processing-1'].effects,
  slag1start + 3,
  lib.takeeffect('slag-processing-2', 'slag-processing-6')) -- move ore6 to slag-processing-1

-- Move crystallization ore recipes up above crushed ores
data.raw['item-subgroup']['slag-processing'].order = "ab"

-- Remove blue science requirement for slag-processing-2 technology
-- Needed for gold ore
-- Update: Not needed for gold now we unlock Rubyte ore with the above technology shuffle.
-- Leave change in because slag-processing-2 unlocks ceramic filters, which are quite helpful.
-- Also, having a source of silver (from crotinnum) early allows making resin/rubber
lib.removeingredient(data.raw.technology['slag-processing-2'].unit.ingredients, 'science-pack-3')

-- Red science level research for slag processing 1
data.raw.technology['slag-processing-1'].unit = {
  count = 20,
  ingredients = {{'science-pack-1', 1}},
  time = 15
}

-- Disable coal cracking technology
data.raw.technology['angels-coal-cracking'].enabled = false

-- Add alien bioprocessing prerequisite for technologies that need alien artifacts
local artifacttech = 'bio-processing-alien'
if data.raw.technology['big-alien-artifacts'] and
  (data.raw.technology['big-alien-artifacts'].enabled == nil or
   data.raw.technology['big-alien-artifacts'].enabled) then
   artifacttech = 'big-alien-artifacts'
end
if data.raw.technology['alien-research'] then
  table.insert(data.raw.technology['alien-research'].prerequisites, artifacttech)
end

-- No way to make light fuel/fuel oil, so use methanol instead
-- Update: can make light-oil now with bioprocessing or algae liqufaction.
lib.substingredient("sct-t3-flash-fuel", "light-oil", "gas-methanol")

-- Move misc sciencey things over to science tab
if data.raw['item-group']['sct-science'] then
  if data.raw.item['lab-2'] then
    -- S.C.T. disables lab-2, re-enable it
    local hiddenidx = lib.tablefind(data.raw.item['lab-2'].flags, "hidden")
    if hiddenidx then
      table.remove(data.raw.item['lab-2'].flags, hiddenidx)
    end
    if lib.findeffectidx(data.raw.technology['advanced-electronics-3'], 'lab-2') == nil then
      table.insert(data.raw.technology['advanced-electronics-3'].effects,
        {type = "unlock-recipe", recipe = "lab-2"})
    end

    data.raw.item['lab-2'].subgroup = "sct-labs"
    data.raw.item['lab-2'].order = "d[xlab-2]"

    -- Update lab MK2 ingredients and energy usage
    lib.substingredient('lab-2', 'lab', 'sct-lab-4')
    lib.substingredient('lab-2', 'advanced-circuit', 'advanced-processing-unit')
    data.raw.lab['lab-2'].energy_usage = "3MW"
    -- Only two module slots for lab-2 if s.c.t. is installed (other labs have no module slots)
    data.raw.lab['lab-2'].module_specification.module_slots = 2
  end
  -- Put centrifuge next to nuclear components
  data.raw.item['centrifuge'].subgroup = "energy"
  data.raw.item['centrifuge'].order = "f[nuclear-energy]-a[centrifuge]"

  -- Remove bob's fluid products item group. This reduces the total number of groups
  -- to 18, 3 rows of 6.
  data.raw['item-group']['bob-fluid-products'] = nil
  for k,v in pairs(data.raw['item-subgroup']) do
    if v.group == 'bob-fluid-products' then
      v.group = 'bob-resource-products'
    end
  end
end

if data.raw.item["OilSteamBoiler"] then
  data.raw.item["OilSteamBoiler"].subgroup = "energy"
  data.raw.item["OilSteamBoiler"].order = "b[steam-power]-b[OilSteamBoiler]"
end

-- No fuel value on these because they are also smelting inputs
-- https://forums.factorio.com/viewtopic.php?f=23&t=46634
data.raw.item['wood-bricks'].fuel_value = nil
data.raw.item['wood-bricks'].fuel_category = nil

-- First stage:                    pipe  pipe-to-ground iron-gear iron-stick
-- Electrolyser  5 circuit board                                  20
-- Liquifier     5 circuit board         2
-- Flare stack   5 circuit board*2 10*2
-- Offshore pump 2 circuit board*2 1*2                  10*2
-- Crystallizer  5 circuit board                                             5 copper-pipe

-- Second stage:
-- Hydro plant   5 electronic      5
-- Clarifier     5 circuit board                        5
-- Algae farm    5 circuit board                                  16
local knowningredients = {
['angels-electrolyser'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'iron-stick', 20},
  {'stone-brick', 10}
},
['liquifier'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'pipe-to-ground', 2},
  {'stone-brick', 10}
},
['offshore-pump'] = {
  {'basic-circuit-board', 2},
  {'pipe', 1},
  {'iron-gear-wheel', 10}
},
['crystallizer'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'copper-pipe', 5},
  {'stone-brick', 10}
},
['hydro-plant'] = {
  {'iron-plate', 10},
  {'electronic-circuit', 5},
  {'pipe', 5},
  {'stone-brick', 10}
},
['algae-farm'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'iron-stick', 16},
  {'stone-brick', 25}
},
['angels-flare-stack'] = {
  {'iron-plate', 5},
  {'basic-circuit-board', 5},
  {'pipe', 10},
  {'stone-brick', 10}
},
['clarifier'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'iron-gear-wheel', 5},
  {'stone-brick', 10}
},
['seafloor-pump'] = {
  {'iron-plate', 5},
  {'basic-circuit-board', 2},
  {'pipe', 5}
},
['washing-plant'] = {
  {'iron-plate', 10},
  {'basic-circuit-board', 5},
  {'pipe', 10},
  {'stone-brick', 10}
},
['angels-chemical-plant'] = {
  {'iron-plate', 5},
  {'iron-gear-wheel', 5},
  {'basic-circuit-board', 5},
  {'pipe', 5}
},
['filtration-unit'] = {
  {'iron-plate', 5},
  {'basic-circuit-board', 5},
  {'pipe', 10},
  {'stone-brick', 10}
},
['filter-frame'] = {
  {'iron-plate', 1},
  {'iron-stick', 2}
}
}

data.raw.recipe['angels-flare-stack'].enabled = true
data.raw.technology['angels-flare-stack'].enabled = false
for k,v in pairs(knowningredients) do
  local recipe = data.raw.recipe[k]
  for ek, ev in pairs(recipe.normal or {}) do
    recipe[ek] = ev
  end
  recipe.normal = nil
  recipe.expensive = nil
  recipe.ingredients = {}
  for _, line in pairs(v) do
    table.insert(recipe.ingredients, {type = 'item', name = line[1], amount = line[2]})
  end
end

lib.substingredient('wind-turbine-2', 'iron-plate', 'steel-plate', 2)
data.raw.recipe['wind-turbine-2'].enabled = false
table.insert(data.raw.technology['steel-processing'].effects,
  { type = 'unlock-recipe', recipe = 'wind-turbine-2' })

-- No natural gas, use methane for manganese pellet smelting
lib.substingredient("pellet-manganese-smelting", "gas-natural-1", "gas-methane")

-- Repurpose thermal extractor
local extractor = data.raw['mining-drill']['thermal-extractor']
data.raw['mining-drill']['thermal-extractor'] = nil
data.raw['assembling-machine']['thermal-extractor'] = extractor
extractor.type = 'assembling-machine'
extractor.crafting_speed = 1
extractor.ingredient_count = 2
extractor.fluid_boxes = {
  {
    production_type = 'input',
    base_area = 10,
    base_level = -1,
    pipe_covers = pipecoverspictures(),
    pipe_connections = {{ type = 'input', position = { 5, 3 } }}
  },
  {
    production_type = 'output',
    base_area = 10,
    base_level = 1,
    pipe_covers = pipecoverspictures(),
    pipe_connections = {{ type = 'output', position = { -5, -3 } }}
  }
}
extractor.animation = {
  north = makeextractorlayers(false, false),
  east = makeextractorlayers(true, true),
  south = makeextractorlayers(false, false),
  west = makeextractorlayers(true, true),
}
extractor.crafting_categories = { "thermal-extractor" }
extractor.fixed_recipe = "thermal-extractor-water"
table.insert(data.raw.technology['thermal-water-extraction'].effects,
  { type = "unlock-recipe", recipe = "thermal-extractor-water" })

-- Circuit network wires should not require rubber
data.raw.recipe['green-wire'].ingredients = {{ "electronic-circuit", 1 }, { "copper-cable", 1 }}
data.raw.recipe['red-wire'].ingredients = {{ "electronic-circuit", 1 }, { "copper-cable", 1 }}

-- SpaceMod temp updates
require "SpaceMod-updates"

-- Merge basic chemistry 2 into basic chemistry
for _,v in pairs(data.raw.technology['basic-chemistry-2'].effects) do
  table.insert(data.raw.technology['basic-chemistry'].effects, v)
end
for _,v in pairs(data.raw.technology) do
  for k,prerequisite in pairs(v.prerequisites or {}) do
    if prerequisite == 'basic-chemistry-2' then
      v.prerequisites[k] = 'basic-chemistry'
    end
  end
end
data.raw.technology['basic-chemistry-2'].effects = {}
data.raw.technology['basic-chemistry-2'].enabled = false

-- unlock lab and optional components with bio-wood-processing
table.insert(data.raw.technology['bio-wood-processing'].effects,
  {type = "unlock-recipe", recipe = "lab"})
if data.raw.recipe['sct-lab1-construction'] then
  data.raw.recipe['sct-lab1-construction'].normal.enabled = false
  data.raw.recipe['sct-lab1-construction'].expensive.enabled = false
  table.insert(data.raw.technology['bio-wood-processing'].effects,
    { type = 'unlock-recipe', recipe = 'sct-lab1-construction' })
end
if data.raw.recipe['sct-lab1-mechanization'] then
  data.raw.recipe['sct-lab1-mechanization'].normal.enabled = false
  data.raw.recipe['sct-lab1-mechanization'].expensive.enabled = false
  table.insert(data.raw.technology['bio-wood-processing'].effects,
    { type = 'unlock-recipe', recipe = 'sct-lab1-mechanization' })
end
if data.raw.recipe['lab'].normal then
  data.raw.recipe['lab'].normal.enabled = false
  data.raw.recipe['lab'].expensive.enabled = false
else
  data.raw.recipe['lab'].enabled = false
end

local startuprecipes = {
  ['angels-electrolyser'] = true,
  ['liquifier'] = true,
  ['offshore-pump'] = true,
  ['angels-flare-stack'] = true,
  ['burner-ore-crusher'] = true,
  ['stone-crushed'] = true,
  ['stone-brick'] = true,
  ['crystallizer'] = true,

  ['dirt-water-separation'] = true,
  ['sb-cellulose-foraging'] = true,
  ['sb-water-mineralized-crystallization'] = true,
  ['iron-plate'] = true,
  ['copper-plate'] = true,
  ['angelsore1-crushed-hand'] = true,
  ['angelsore3-crushed-hand'] = true,
  ['angelsore1-crushed-smelting'] = true,
  ['angelsore3-crushed-smelting'] = true,
  ['wood-pellets'] = true,
  ['slag-processing-stone'] = true,
  ['water-mineralized'] = true,
  ['stone-pipe'] = true,
  ['stone-pipe-to-ground'] = true
}

local sbtechs = {
  ['sb-startup1'] = true,
  ['sb-startup2'] = true,
  ['bio-wood-processing'] = true,
  --['sb-startup3'] = true,
  --['sb-startup-sulfur'] = true,
  ['sb-startup4'] = true
}
local startuptechs = {
  ['automation'] = true,
  ['logistics'] = true,
  ['optics'] = true,
  ['turrets'] = true,
  ['stone-walls'] = true,
  ['basic-chemistry'] = true,
  ['ore-crushing'] = true,
  ['steel-processing'] = true,
  ['military'] = true,
  ['angels-sulfur-processing-1'] = true,
  ['water-treatment'] = true,
  ['water-washing-1'] = true,
  ['slag-processing-1'] = true,
  ['angels-fluid-control'] = true,
  ['angels-metallurgy-1'] = true,
  ['angels-iron-smelting-1'] = true,
  ['angels-copper-smelting-1'] = true,
  ['angels-coal-processing'] = true,
  ['bio-wood-processing-2'] = true,

  ['landfill'] = true
}
if data.raw.technology['bob-logistics-0'] then
  startuptechs['bob-logistics-0'] = true
end
local lasttech = 'sb-startup4'

local movedrecipes = table.deepcopy(startuprecipes)
for k,v in pairs(sbtechs) do
  for _,effect in pairs(data.raw.technology[k].effects or {}) do
    movedrecipes[effect.recipe] = true
  end
end
local disabledrecipes = {}

-- Don't want any recipes available that consume our carefully
-- selected starting items until the self-sufficient startup is complete
local function ironrecipe(recipe)
  local foundiron = false
  local ironnames = {
    ['iron-plate'] = true,
    ['iron-gear-wheel'] = true,
    ['iron-stick'] = true,
    ['pipe'] = true,
    ['pipe-to-ground'] = true,
    ['basic-circuit-board'] = true,
    ['electronic-circuit'] = true,
    ['stone-brick'] = true,
    ['copper-plate'] = true,
    ['copper-cable'] = true,
    ['stone-furnace'] = true
  }
  local function scaningredients(recipe)
    local haveiron = true
    for k,v in pairs(recipe.ingredients) do
      local nameidx = 1
      if v.name then nameidx = 'name' end
      if not ironnames[v[nameidx]] then
        haveiron = false
      end
    end
    foundiron = foundiron or haveiron
  end
  lib.iteraterecipes(recipe, scaningredients)
  return foundiron
end
-- Disable recipes that shouldn't consume startup items
for k,v in pairs(data.raw.recipe) do
  local r = v.normal or v
  if (r.enabled == nil or r.enabled == true or r.enabled == 'true') and
    ironrecipe(v) and
    not v.hidden then
    if not movedrecipes[k] then
      table.insert(disabledrecipes, k)
    end
    r.enabled = false
    if v.normal then
      v.expensive.enabled = false
    end
  end
end

-- Add prerequisites to technologies which are not part of the selected startup techs.
for k,v in pairs(data.raw.technology) do
  if (v.enabled == nil or v.enabled == true or v.enabled == 'true') and not sbtechs[k] then
    if not v.prerequisites or #v.prerequisites == 0 then
      local prerequisite = 'slag-processing-1'
      if startuptechs[k] then
        prerequisite = lasttech
      end
      v.prerequisites = {prerequisite}
    end
  end
  if v.effects and not sbtechs[k] then
    local neweffects = {}
    for _,effect in pairs(v.effects) do
      if effect.type ~= "unlock-recipe" or not movedrecipes[effect.recipe] then
        table.insert(neweffects, effect)
      end
    end
    v.effects = neweffects
  end
end

-- Disabled recipes are enabled at last stage of startup. (Laboratory research)
for _,v in pairs(disabledrecipes) do
  table.insert(data.raw.technology[lasttech].effects, {type="unlock-recipe", recipe=v})
end
for k,_ in pairs(startuprecipes) do
  local recipe = data.raw.recipe[k]
  if recipe.normal then
    recipe.normal.enabled = true
    recipe.expensive.enabled = true
  else
    recipe.enabled = true
  end
end

data.raw.technology['landfill'].prerequisites = {}
data.raw.technology['water-washing-1'].prerequisites = {'ore-crushing'} -- Allow skipping of waste water recycling
table.insert(data.raw.technology['water-treatment'].effects,
  lib.takeeffect('water-treatment-2', 'yellow-waste-water-purification'))
table.insert(data.raw.technology['electronics'].prerequisites, 'slag-processing-1')

-- Limit research required for startup techs.
for k,_ in pairs(startuptechs) do
  if data.raw.technology[k].unit.count > 20 then
    data.raw.technology[k].unit.count = 20
  end
end

-- Green science is unlocked by automation-2. In case people are playing without S.C.T.
data.raw.recipe['science-pack-2'].enabled = false
if lib.findeffectidx(data.raw.technology['automation-2'].effects, 'science-pack-2') == nil then
  table.insert(data.raw.technology['automation-2'].effects, {type = 'unlock-recipe', recipe = 'science-pack-2'})
end

-- Make bio-wood-processing a startup tutorial tech
data.raw.technology['bio-wood-processing'].prerequisites = {'sb-startup2'}
data.raw.technology['bio-wood-processing'].unit = {
  count = 1,
  ingredients = {{"sb-algae-green-tool", 1}},
  time = 5
}
lib.takeeffect('bio-wood-processing', 'wood-pellets')
lib.takeeffect('bio-wood-processing', 'gas-carbon-dioxide-from-wood')
table.insert(data.raw.technology['bio-wood-processing'].effects,
  {type = 'unlock-recipe', recipe = 'cellulose-fiber-algae'})
table.insert(data.raw.technology['bio-wood-processing'].effects,
  {type = 'unlock-recipe', recipe = 'small-electric-pole'})
table.insert(data.raw.technology['bio-wood-processing'].effects,
  lib.takeeffect('bio-wood-processing-3', 'wood-bricks'))
table.insert(data.raw.technology['bio-wood-processing-2'].effects,
  {type = 'unlock-recipe', recipe = 'sb-wood-bricks-charcoal'})
data.raw.technology['bio-wood-processing-2'].prerequisites = { lasttech }
table.insert(data.raw.technology['bio-wood-processing-3'].effects,
  lib.takeeffect('bio-wood-processing', 'wood-from-cellulose'))
data.raw.technology['bio-paper-1'].prerequisites = {}

-- KS_Power oil boiler recipes produce 90 units of 165 degree steam
-- (165 - 15) * 90 * 0.2kJ = 2.7 MJ per product

-- from prototypes/recipe.lua
    -- 2 solid fuel (50MJ) = 1 coke (5MJ) + 100 naphtha. 100 naphtha = 45 MJ
    -- 2 solid fuel (50MJ) = 1 coke (5MJ) + 50 fuel oil. 50 fuel oil = 45 MJ
    -- basic oil refining is 100 crude oil -> 30 fuel oil + 50 naphtha (and other stuff i'll ignore)
    -- 100 crude oil = 30/50*45 + 50/100*45 MJ = 49.5 MJ
    -- 100 multiphase oil = 49.5*70/100 = 34.65 MJ.

-- crude oil 100 * 2.7 / 49.5 = 5.45
lib.findname(data.raw.recipe['burn-crude-oil'].ingredients, 'crude-oil').amount = 8

local function updatefuel(recipe, to, amount)
  data.raw.recipe[recipe].localised_name = {"burn", {"fluid-name."..to}}
  data.raw.recipe[recipe].icons[1].icon = data.raw.fluid[to].icon
  data.raw.recipe[recipe].ingredients[2].name = to
  data.raw.recipe[recipe].ingredients[2].amount = amount
end
-- heavy oil 100 * 2.7 / 45 = 6
updatefuel('burn-heavy-oil', 'liquid-naphtha', 6)

-- methane, same as heavy oil
updatefuel('burn-petroleum-gas', 'gas-methane', 6)

-- light oil 50 * 2.7 / 45 = 3
updatefuel('burn-light-oil', 'liquid-fuel-oil', 3)

-- diesel, same as light oil
data.raw.recipe['burn-diesel-fuel'].ingredients[2].amount = 3

-- Remove some unusual fuel sources from oil burner
lib.takeeffect('OilBurning', 'burn-glycerol')
lib.takeeffect('OilBurning', 'burn-hydrazine')
lib.takeeffect('OilBurning', 'burn-hydrogen')
lib.takeeffect('OilBurning', 'burn-liquid-fuel')
data.raw.fluid['hydrogen'].fuel_value = nil
if data.raw.fluid['glycerol'] then
  data.raw.fluid['glycerol'].fuel_value = nil
end

-- Make hydrazine solid fuel match fuel_value
if data.raw.fluid['hydrazine'] then
  local hydrazinevalue = data.raw.fluid['hydrazine'].fuel_value
  data.raw.fluid['gas-hydrazine'].fuel_value = hydrazinevalue
  if hydrazinevalue:sub(-2) == 'KJ' then
    local hydrazinevaluekj = tonumber(hydrazinevalue:sub(1, -3))
    data.raw.recipe['solid-fuel-hydrazine'].ingredients[1].amount = 50000 / hydrazinevaluekj
  end
end

-- Make bobpower hydrazine generator use angels hydrazine
if data.raw.generator['hydrazine-generator'] then
  data.raw.generator['hydrazine-generator'].fluid_box.filter = 'gas-hydrazine'
end

-- petroleum gas/methane has same solid fuel value as naphtha.
data.raw.fluid['liquid-fuel-oil'].fuel_value = '1.25MJ' -- 1MJ + 25% increase because blue science
data.raw.fluid['light-oil'].fuel_value = '1.25MJ'
data.raw.fluid['liquid-fuel'].fuel_value = '1.25MJ'
data.raw.fluid['liquid-naphtha'].fuel_value = '0.625MJ'
data.raw.fluid['heavy-oil'].fuel_value = '0.625MJ'
data.raw.fluid['gas-methane'].fuel_value = '0.625MJ'
data.raw.fluid['petroleum-gas'].fuel_value = '0.625MJ'
-- 20 petroleum gas + 20 light fuel = 30 diesel
-- 20/100*45 + 20/50*45 = 27MJ = 30 diesel
data.raw.fluid['diesel-fuel'].fuel_value = '1.5MJ' -- 1MJ + 50% bonus
-- Increase consumption of generators, sea block fuel values are lower than other mods expect.
data.raw.generator['petroleum-generator'].fluid_usage_per_tick = 3/60

-- KS_Power diesel generator is 100% efficient, put it after bob's fluid generators in tech tree
if data.raw.technology['fluid-generator-3'] then
  table.insert(data.raw.technology['petroleum-generator'].prerequisites, "fluid-generator-3")
  table.insert(data.raw.technology['petroleum-generator'].unit.ingredients,
    {"production-science-pack", 1})
end

-- Remove wood from basic underground belt and splitter recipes
if data.raw.recipe['basic-underground-belt'] then
  lib.removeingredient(data.raw.recipe['basic-underground-belt'].ingredients, 'wood')
end
if data.raw.recipe['basic-splitter'] then
  lib.removeingredient(data.raw.recipe['basic-splitter'].ingredients, 'wood')
end

-- Reduce processing unit cost of S.C.T. high-tech science
lib.substingredient('sct-htech-injector', 'processing-unit', nil, 3)
