for _, force in pairs(game.forces) do
  force.technologies['sb-startup1'].researched = true
  force.technologies['sb-startup2'].researched = true
  force.technologies['bio-wood-processing'].researched = true
  --force.technologies['sb-startup3'].researched = true
  force.technologies['sb-startup4'].researched = true
end
