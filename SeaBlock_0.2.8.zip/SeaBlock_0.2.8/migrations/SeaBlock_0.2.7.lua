for _,force in pairs(game.forces) do
  if force.technologies['advanced-electronics'].researched and force.technologies['advanced-research'] then
    force.technologies['advanced-research'].researched = true
  end
end

